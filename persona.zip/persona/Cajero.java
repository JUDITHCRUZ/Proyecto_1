
package persona;

public class Cajero
{
   // Variables

            String Cajero_ID;
            String Cajero_Nombre;
            String Cajero_Apellidos;
            String Entidad_Financiera;
            String Actividad_Acargo;
            String Entidad_Financiera_Acargo;

public Cajero(String[] pCajeros)
    {
            Cajero_ID = pCajeros[0];     
            Cajero_Nombre = pCajeros[1];
            Cajero_Apellidos = pCajeros[2];
            Entidad_Financiera = pCajeros[3];
            Actividad_Acargo = pCajeros[4];
            Entidad_Financiera_Acargo =pCajeros[5];
             
    }

//Setters and Getters
 public void set_Cajero_ID (String Caj_ID) 
    {
        Cajero_ID=Caj_ID;
      
    }
 public void set_Cajero_Nombre(String Cajero_Nom) 
    {
        Cajero_Nombre= Cajero_Nom ;
    }
 public void set_Cajero_Apellido(String Cajero_Ape) 
    {
        
        Cajero_Apellidos= Cajero_Ape;
    }
 
public String get_Cajero_ID()
    { 
        return Cajero_ID;
    } 
 
 public String get_Cajero_Nombre()
    { 
        return Cajero_Nombre;
    } 
 
 public String get_Cajero_Apellido()
    { 
        return Cajero_Apellidos;
    } 
 
 
}    