/*
 * El objetivo de este programa es abstraer a un cliente de banco. Esta clase provee informacion a la Entidad Financiera, clase principal de es
   este proyecto.
  
 */
package persona;

import java.io.BufferedReader;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.PrintStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Cliente 
{
   
    String identificacion;
    String direccion;
    String nom_1;
    //String nom_2;
    String apellidos;
    //String apellido_2;
     int telefono;    
   // Boolean estado_civil; 
   // String oficio;
   // String genero;
    Cuenta cuenta_persona;
    
     // Constructor para lista de clientes
    public Cliente(String[] pDatos)
    {
        identificacion =pDatos[0];     
        direccion =pDatos[2] + " / " + pDatos[1];
        nom_1= pDatos[3];
        //System.out.println(pDatos[4]);
        apellidos = pDatos[4];
        telefono = Integer.parseInt(pDatos[5]);
    
    }
    // Constructor Cliente 1
    public Cliente(String nom_new, String nom_2_new, String ID, String Dic, String A_P1, Cuenta Cuenta )
    {
        identificacion = ID;
        direccion =Dic;
        nom_1 = nom_new;
       cuenta_persona = new Cuenta();
       apellidos= A_P1;
            
    }
    
     
    public void set_nom_1(String nombre) 
    {
        nom_1 = nombre ;
    }
    
   
    public void set_apellidos(String apell_1) 
    {
        apellidos = apell_1 ;
    }
    
       
    public void set_identificacion(String ID) 
    {
        identificacion = ID ;
    }
    
    public void set_telefono (int tel) 
    {
        telefono = tel ;
    }
    
    public void set_direccion(String direcion) 
    {
        direccion =direcion ;
    }
    
    
    
    public String get_nom_1()
    { 
        return nom_1;
    }
    
     
    public String get_apellidos()
    { 
        return apellidos;
    }
    
        
      public String get_identificacion()
    { 
        return identificacion;
    }
    
       public int get_telefono()
    { 
        return telefono;
    }
     
        public String get_direccion()
    { 
        return direccion;
    }
        
    
        public void mostrarEstado ()
    {
       System.out.println ("Nombre del Cliente: "+ nom_1);
       System.out.println("Localidad y Direccion:" + direccion);
       System.out.println("Numero de Telefono:"+ telefono);
       System.out.println("Apellios :" + apellidos);
       System.out.println("Apellios :" + cuenta_persona);
    }
        // Metodo para imprimir el log NO SIRVE
      /*  public void LogFile () throws FileNotFoundException
    {
        String fileName="Transaccion";
        PrintWriter outputStream= new PrintWriter ( fileName);
        outputStream.println("Hi there file!");
        System.out.println("Done");
       
    }
      */
        //Metodo para agregar Clientes a lista de clientes, la excepcion fue tirada y no contemplada, necesito entender mas esto.
         private void agregarClientes(List<Cliente> pclientes) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

  
}
