package persona;
public class Cuenta 
{
double monto;
String Nombre_Entidad_Financiera_Cuenta;
Boolean Trans_Apertura;
Boolean Trans_Cierre;
Boolean Trans_Retiro;
Boolean Trans_Credito;

  //Constructor de Cuenta para asiganar valores 
    Cuenta() 
    {
      monto=100000;
      Nombre_Entidad_Financiera_Cuenta = "Banco Nacional";
      Trans_Apertura = true; 
      Trans_Cierre = false;
      Trans_Retiro = false;
      Trans_Credito =false;
    }
//Constructor de Cuenta  

    public Cuenta(double monto, String Nombre_Entidad_Financiera_Cuenta, Boolean Trans_Apertura, Boolean Trans_Cierre, Boolean Trans_Retiro, Boolean Trans_Credito) {
        this.monto = monto;
        this.Nombre_Entidad_Financiera_Cuenta = Nombre_Entidad_Financiera_Cuenta;
        this.Trans_Apertura = Trans_Apertura;
        this.Trans_Cierre = Trans_Cierre;
        this.Trans_Retiro = Trans_Retiro;
        this.Trans_Credito = Trans_Credito;
    }
    
    
 
// setters and getters
public void set_monto(double cant_monto) 
{
    monto= cant_monto;
}

public void set_Trans_Apertura(Boolean Trans_Apert) 
{
    Trans_Apertura= Trans_Apert;
}

public void set_Nombre_Entidad_Financiera(String Nom_Ent_Finan) 
{
    Nombre_Entidad_Financiera_Cuenta= Nom_Ent_Finan;
}


public void set_Trans_Cierre(Boolean Trans_Cier)
{
    Trans_Cierre= Trans_Cier;
}

public void set_Trans_Retiro(Boolean Trans_Ret)
{
    Trans_Retiro= Trans_Ret;
}

public double get_monto()
{ 
    return monto;
}
public String get_Nombre_Entidad_Financiera()
{ 
    return Nombre_Entidad_Financiera_Cuenta;
}
public Boolean get_Trans_Apertura()
{ 
    return Trans_Apertura;
}
public Boolean get_Trans_Cierre()
{ 
    return Trans_Cierre;
}

public Boolean get_Retiro()
{ 
    return Trans_Retiro;
}

public String toString()

{
return Nombre_Entidad_Financiera_Cuenta;
}

//Mostrar Estado de cuenta
public void mostrarEstado()

{
System.out.println("Monto"+" "+ monto +"\n"+"Nombre de la Entidad Visitada: "+ Nombre_Entidad_Financiera_Cuenta +"\n"+"Typo de transaccion (Apertura):"+ 
Trans_Apertura +"\n"+"Typo de transaccion (Cierre):"+ Trans_Cierre +"\n"+"Typo de transaccion (Retiro):"+ Trans_Retiro +"\n"+"Typo de transaccion (Credito):"+ Trans_Credito);

}

}
