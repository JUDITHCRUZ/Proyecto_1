// Este programa imprime la reporta la informacion de una entidad financiera. 
// Tiene como clase a Cliente: brinda los atributos basicos de los clientes que visitan la financiera para hacer sus transacciones.
//Ademas, se apoya en la clase cuenta que provee las propiedades minimas de cada una de las cuentas.
//Finalmente cuenta con la clase cajero que brinda la informacion de los cajeros y sus propiedades basicas.
// El proyecto permite importar informacion de articulas CSV y agregarla a las clases necesarias para popular un reporte final.
// Los CSVs son proporcionados junto con el proyecto, se puede agregar mas informacion a nivel de lineas, pero para agregar mas datos a nivel de columnas deben
// ser mapeadas a las propiedades y respectivos for loops.
// Como aclaracion se establece que parte de codigo esta en ingles porque fue adaptado de video tutoriales en youtube, no es de interes de la autora apropiarse de los derechos de autor.
// Programa desarrollado en Feb-2017 por JUDITH CRUZ
package persona;

import java.io.BufferedReader;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.PrintStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Entidad_Financiera 
{

    private static void generarCSVfile(String cUsersjcruzDocumentsNetBeansProjectsPerso)
    {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    // Propiedades de la entidad financiera
    String Nombre;
    String Direccion;
    int telefono;
    int Fax;
    List<Cliente> personas;
    List<Cajero> Cajeros;
    Cuenta cuenta_persona;
   
    
    //Constructor 1 de las propiedades minimas de la entidad financiera donde se llevo acabo la transaccion
    public Entidad_Financiera(String inNombre1,String dir, int tel )
    {
        Nombre = inNombre1;
        Direccion= dir;
        telefono = tel;
        //cuenta_persona= CP;
       personas= new ArrayList<>();
       Cajeros= new ArrayList<>();
    }
   

   //Este metodo crea las los elmentos a imprimir para lista de clientes de un CSV 
    public void Imprimir_LC()
    {
    for(int i=0; i<personas.size(); i++)
    {
    System.out.println("ID:"+personas.get(i).identificacion +"  " +"Nombre:"+ personas.get(i).nom_1+"  " + "Apellidos:" + personas.get(i).apellidos+
    "  " +"Tel:"+personas.get(i).telefono+"  " + "Direcc:"+personas.get(i).direccion +"\n"+"########");
    
    }
        
    }
    
   public void mostrarEstado()
   
   {
   System.out.println("Nombre Entidad donde se Realiza la transaccion: "+Nombre+"\n"+ "Direccion Fisica: "+Direccion+"\n"+"Telefono: "+telefono);
   
   }    
    
    public void Imprimir_LaC()
    {
    for(int i=0; i<Cajeros.size(); i++)
    {
    System.out.println("ID Cajero :"+Cajeros.get(i).Cajero_ID + "  "+ "Nombre :"+Cajeros.get(i).Cajero_Nombre + "--"+ "Apellido :"
    +Cajeros.get(i).Cajero_Apellidos + "--"+"Entidad Financiera:"+Cajeros.get(i).Entidad_Financiera + "--"+"Actividad a Cargo :"
    +Cajeros.get(i).Actividad_Acargo +"--"+ "Entidad Financiera Acargo :" +Cajeros.get(i).Entidad_Financiera_Acargo );
    
    }
        
    }
 // Este metodo importa la lista de clientes de un CSV   
public void Listado_Clientes () throws FileNotFoundException, IOException
    {
     String lines = "";
     FileReader fr = new FileReader ("C:\\Users\\jcruz\\Documents\\NetBeansProjects\\Persona\\src\\persona\\data.csv");
     BufferedReader br =new BufferedReader(fr);
     Cliente CL; 
     List<String> linesRows = new ArrayList<>();
     List <String> RowInfo = null;
     while ((lines =br.readLine()) != null){
          linesRows.add(lines);
         
     }
     //System.out.println(linesRows.get(0));
     for (int i=0; i<linesRows.size(); i++){
          String myArrayRow[];
          myArrayRow=linesRows.get(i).split(",");
          CL=new Cliente(myArrayRow);
          personas.add(CL);
         //for(int e=0; e<myArrayRow.length;e++){
             //System.out.println(myArrayRow[e]);
        // }
         //-------------------------");
     }
          br.close();
             
  //Este metodo importa la lista de cajeros disponibles de un CSV    
    } 
public void Listado_Cajeros () throws FileNotFoundException, IOException
    {
     String lines1 = " ";
     FileReader fre = new FileReader ("C:\\Users\\jcruz\\Documents\\NetBeansProjects\\Persona\\src\\persona\\cajeros.csv");
     BufferedReader br =new BufferedReader(fre);
     Cajero CaL; 
     List<String> linesRows = new ArrayList<>();
     List <String> RowInfo = null;
     while ((lines1 =br.readLine()) != null){
          linesRows.add(lines1);
         
     }
     //System.out.println(linesRows.get(0));
     for (int i=0; i<linesRows.size(); i++){
          String myArrayRow1[];
          myArrayRow1=linesRows.get(i).split(",");
          CaL=new Cajero(myArrayRow1);
          Cajeros.add(CaL);
         //for(int e=0; e<myArrayRow.length;e++){
             //System.out.println(myArrayRow[e]);
        // }
         //-------------------------");
     }
          br.close();
             
      
    } 


   public static void main(String[] args) throws IOException 
   {
      
   Entidad_Financiera f1 = new Entidad_Financiera("Banco Interamericano","200 m Este de la Basilica de Cartago",552568);
      f1.mostrarEstado();
      System.out.println("***********************************************************************************************************************************************************"+ "\n");
      System.out.println("***********************************************************************************************************************************************************"+ "\n");
      
      System.out.println("Transaccion Realizada");
      Cuenta C1 = new Cuenta();   
      C1.mostrarEstado();
      System.out.println("***********************************************************************************************************************************************************"+ "\n");
      System.out.println("***********************************************************************************************************************************************************"+ "\n");
      
      
      f1.Listado_Clientes();
      f1. Listado_Cajeros();
      System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------");
      System.out.println("Total de Clientes Atendidos: "+f1.personas.size());
      System.out.println("Lista de Clientes Atendidos");
      System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------");
      f1.Imprimir_LC();
      System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------");
      System.out.println("Total de Cajeros Activos en la Entidad Bancaria :"+f1.Cajeros.size());
      System.out.println("Lista de Clientes Atendidos: ");
      System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------");
      f1.Imprimir_LaC();
     System.out.println("***********************************************************************************************************************************************************"+ "\n");
    
     //generarCSVfile("C:\\Users\\jcruz\\Documents\\NetBeansProjects\\Persona\\src\\persona\\reporte.csv");
     //System.out.println("CVS creado exitosamente");
   } 
   /* public static void generarCSVfile()
    {
   
        String sFileName = null;
        try {
            FileWriter writer = new FileWriter (sFileName);
            Writer.append(persona.Entidad_Financiera.main(args));
        }
        catch (IOException ex) {
            Logger.getLogger(Entidad_Financiera.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }
    */
  }

   
    
    

